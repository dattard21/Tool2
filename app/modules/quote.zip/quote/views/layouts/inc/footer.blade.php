<nav class="navbar navbar-default navbar-fixed-bottom" style="position:relative !important;;background-color: #f1f1f1;z-index: 0 !important;margin-bottom: 0px !important;">
    <div class="navbar-header">
        <a class="navbar-brand" style='left:44% !important;float:none;position:absolute;color:black;font-size: 14px;'>&copy; 2014 | Jay Sheth</a>
    </div>                        
</nav>