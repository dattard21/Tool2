<!--<nav class="navbar navbar-inverse" style="min-width: 1143px !important;">    
    <div class="navbar-header" style="left:11.5%;position:absolute;">
        <a class="navbar-brand" style="font-size:30px !important;color:#fff !important;" href="{{ URL::to('quote') }}">Humans</a>
    </div>

</nav>-->

<nav class="navbar navbar-inverse" style="">    
    <div class="navbar-header" style="width:100% !important">
        <center>
            <a class="" style="font-size:30px !important;color:#fff !important;" href="{{ URL::to('quote') }}">Quote Generator</a>
        </center>
    </div>

</nav>