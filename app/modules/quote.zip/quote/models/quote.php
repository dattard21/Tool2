<?php

namespace quote;

use DB;
    

Class quote extends \Eloquent {

    public $timestamps = false;    

}

?>
